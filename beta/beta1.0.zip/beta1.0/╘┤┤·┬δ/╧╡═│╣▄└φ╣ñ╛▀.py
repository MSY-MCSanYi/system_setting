import os
import time
import tkinter as tk
from PIL import Image,ImageTk
#=========前置===========#
def user_agreement(): #用户协议
    os.system("cls")
    with open("C:\\system_file\\user_agreement.txt","w") as f:
        f.write("已同意用户协议")
        f.close()
    with open("C:\\system_file\\readme.txt","w") as f:
        f.write("这些是系统管理工具的用户信息配置，不要乱删哦！不然会出现bug")
        f.close()
    os.system("cls")
    print("已同意此用户协议")
    print("重新进入即可使用该软件")
    os.system("pause")
    quit()

def clear():
    os.system("CHCP 65001")
    os.system("cls")
    time.sleep(0.2)
    os.system("pause")

#===================主要========================#
def catalogue():#菜单
    os.system("cls")
    print("欢迎来到系统管理工具")
    list_1=["1.系统轻松设置","2.版本信息","3.退出"]
    print("****************************")
    for i in list_1:
        print(i)
    print("****************************")

def version():
    root = tk.Tk()
    a = tk.Frame(root)
    a.pack()
    b = Image.open('.\\data\\picture\\beta1.0.png')
    b = ImageTk.PhotoImage(b)
    tk.Label(a, image=b).pack()
    root.mainloop()

if __name__ == "__main__":
    os.system("CHCP 65001")
    os.system("cls")
    if os.path.exists("C:\\system_file\\user_agreement.txt"):
        while True:
            catalogue()
            ai=input("选择(输入程序对应的编号):")
            if ai=="1":
                os.system("start .\data\software\Windows11_setting\win_setting.exe")
                os.system("cls")
            elif ai=="2":
                version()
            else:
                quit()
    else:
        print('''用户协议:
1.本软件要有一定的计算机基础才可以使用哦
2.不要乱设置，可能会出现一些系统的问题
3.最最最最重要的，不懂那些就不要设置！
4.Press any key to continue的意思是按任意键继续
''')
        print("Y同意,N不同意")
        ai=input("请输入:")
        if ai=="Y":
            os.system("md C:\system_file")
            user_agreement()
        else:
            quit()

